import React from "react";
import { Text, View, StyleSheet } from "react-native";

export default function ayurvedicScreen() {
  return (
    <View style={styles.main}>
      <Text>Ayurvedic Centers</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  main: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
});

//MedyLifeLine

import React from "react";
import { StyleSheet, Text, View, TouchableOpacity } from "react-native";
import Icon from "react-native-vector-icons/Ionicons";
import Icon1 from "react-native-vector-icons/FontAwesome";
import Icon3 from "react-native-vector-icons/MaterialCommunityIcons";
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from "react-native-responsive-screen";

const medylifeline = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.tabBar}>
          <TouchableOpacity>
            <Icon name="md-menu" size={35} color="#fff" />
          </TouchableOpacity>
          <View style={styles.icon}>
            <TouchableOpacity>
              <Icon
                style={{ marginRight: 20 }}
                name="md-notifications"
                size={35}
                color="#fff"
              />
            </TouchableOpacity>
            <TouchableOpacity>
              <Icon name="md-person" size={35} color="#fff" />
            </TouchableOpacity>
          </View>
        </View>
        <View style={styles.header0}>
          <Text style={styles.headerText0}>Welcome</Text>
          <Text style={styles.headerText1}>to</Text>
          <Text style={styles.headerText2}>MedyLifeLine</Text>
        </View>
      </View>
      <View style={styles.footer}>
        <View style={styles.card}>
          <TouchableOpacity
            style={{ ...styles.option, ...{ backgroundColor: "#ea3639" } }}
          >
            <Icon1 name="id-card" size={40} color="#fff" />
            <Text style={styles.cardText}>My MedyLifeLine Card</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={{ ...styles.option, ...{ backgroundColor: "#eb9234" } }}
          >
            <Icon name="md-git-network" size={45} color="#fff" />
            <Text style={styles.cardText}>Network Centers</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.line}></View>
        <View style={styles.card}>
          <TouchableOpacity
            style={{ ...styles.option, ...{ backgroundColor: "#c0cf15" } }}
          >
            <Icon3 name="autorenew" size={45} color="#fff" />
            <Text style={styles.cardText}>Renewal Details</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={{ ...styles.option, ...{ backgroundColor: "#00a305" } }}
          >
            <Icon3 name="credit-card-plus-outline" size={45} color="#fff" />
            <Text style={styles.cardText}>Request For New Card</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.card}>
          <TouchableOpacity
            style={{ ...styles.option, ...{ backgroundColor: "#2ca0e8" } }}
          >
            <Icon name="md-settings" size={45} color="#fff" />
            <Text style={styles.cardText}>Settings</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={{ ...styles.option, ...{ backgroundColor: "#a226e0" } }}
          >
            <Icon name="md-information-circle" size={45} color="#fff" />
            <Text style={styles.cardText}>About</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

export default medylifeline;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  tabBar: {
    padding: 35,
    flexDirection: "row",
    justifyContent: "space-between",
  },
  header: {
    flex: 2,
    backgroundColor: "#1573d6",
    borderBottomStartRadius: 60,
    borderBottomEndRadius: 60,
  },
  header0: {
    marginTop: 10,
    justifyContent: "center",
    alignItems: "center",
  },
  footer: {
    flex: 3,
    marginTop: -80,
  },
  headerText0: {
    color: "#fff",
    fontSize: 30,
    fontWeight: "bold",
  },
  headerText1: {
    color: "#fff",
    fontSize: 25,
    fontWeight: "bold",
  },
  headerText2: {
    color: "#fff",
    fontSize: 40,
    fontWeight: "bold",
  },
  card: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginTop: -5,
  },
  cardText: {
    color: "#fff",
    fontSize: 17,
    fontWeight: "bold",
    textAlign: "center",
    paddingTop: 5,
  },
  option: {
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 20,
    margin: 15,
    height: hp("18%"),
    width: wp("34%"),
  },
  icon: {
    flexDirection: "row",
  },
});
